# Arix Blueprint Integration

This document explains how Arix Theme v2.1.0 integrates with Blueprint extensions dynamically, without requiring manual edits to the theme's core routing files.

## How Blueprint Routes Are Discovered
During the Pterodactyl frontend asset compilation (`yarn build:production`), Webpack statically analyzes the codebase. We use Webpack's `require.context` to scan the `resources/scripts` directory for Blueprint's generated route file, typically located at `resources/scripts/blueprint/extends/routers/routes.ts`. 

If this file exists (meaning Blueprint is installed and has generated routes), it is dynamically bundled. If it does not exist (meaning Blueprint is absent or has no extensions), the build safely falls back to empty arrays and Arix functions natively.

## How Components Are Resolved
Because Blueprint handles the generation of `blueprint/extends/routers/routes.ts`, it also handles all component imports from `@blueprint/...`. Webpack natively resolves these during compilation. Arix simply mounts the pre-resolved `React.ComponentType` exported by the Blueprint router.

## Route Merging & Precedence
When Arix boots on the client, it merges its native `routes.server` and `routes.account` arrays with the dynamically loaded Blueprint routes.
- Duplicate detection is enforced by checking route paths.
- **Arix Native Precedence:** If a Blueprint extension attempts to overwrite an existing Arix core route (e.g., `/files`), it is safely ignored to prevent panel corruption.

## Navigation & UI Synchronization
Blueprint navigation links are automatically populated in the server sidebar under an **"Extensions"** category.
However, to preserve Arix's robust customization:
- If a server administrator manually configures a Blueprint route in the Arix settings UI (e.g., placing `/plugins` into a custom "Management" category), the automatic injection skips that route to prevent duplicates.
- The `MissingLinks` view in the Arix Admin Settings now naturally detects Blueprint routes, allowing administrators to customize their visibility, tier restrictions, and icons visually.

## Permissions & Tier Restrictions
- Blueprint route metadata (e.g., `adminOnly` and `permission`) is passed directly into Arix's `<PermissionRoute>` wrapper, ensuring Pterodactyl core authorization constraints are fully respected.
- Arix Tier Restrictions remain compatible. If an administrator applies a tier restriction to a Blueprint route via the Arix UI, the `ComponentLoader` correctly evaluates it and hides the component for unauthorized tiers.

## Extension Removal
If an extension is disabled or removed, Blueprint rebuilds its route registry. Upon the next Webpack build, the route is excluded. Arix's dynamic loader will automatically cease rendering the route and its associated sidebar link. No dead links or 404s will remain.
